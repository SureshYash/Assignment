/*Write down program to remove all digits and special character from the given
sentence*/

public class RemoveSpecialCharDigits {

	public static void main(String args[]) {
		String stringToverfiy = "This#string%contains^special*characters&. and digits 124";
		stringToverfiy = stringToverfiy.replaceAll("[^a-zA-Z]", " ");// replacing the special cahracter and digits
		System.out.println(stringToverfiy);//printing word after the replace
	}//main end
}//class end