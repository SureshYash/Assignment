/*Write down program to reverse every word in given sentence*/
import java.util.*;

public class ReverseWord {
	public void reverseEachWordInString(String sTringToReverse) {
		String[] each_words = sTringToReverse.split(" ");
		String revString = "";
		for (int i = 0; i < each_words.length; i++) {
			String individualWord = each_words[i];
			String reverseWord = "";
			for (int j = individualWord.length() - 1; j >= 0; j--) {
				reverseWord = reverseWord + individualWord.charAt(j);
			}
			revString = revString + reverseWord + " ";
		}
		System.out.println(revString);
	}

	public static void main(String[] args) {
		ReverseWord obj = new ReverseWord();
		String StrGiven = "Yash technologies India Pvt Ltd ";
		System.out.println("Original string is: " + StrGiven);
		System.out.println("The string reversed word in string is: ");
		obj.reverseEachWordInString(StrGiven);
	}
}
