/*A word is entered by user now you have to store word in character array after storing
you have to sort the character*/


import java.util.Arrays;
import java.util.Scanner;

public class SortCharArray {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Sentence: ");
		String name = in.nextLine();
		char[] array = name.toCharArray();
		for (char c : array) {
			System.out.println(c);
		}
		Arrays.sort(array);
		System.out.println("The sorted char array is:");
		for (char ar : array) {
			System.out.println(ar);
		}
	}

}
