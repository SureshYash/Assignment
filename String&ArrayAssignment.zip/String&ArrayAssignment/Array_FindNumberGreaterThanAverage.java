/*Write down program to print all numbers who’s are greater than average of all
numbers of array*/
import java.util.Arrays;

public class AvgGreaterNumberMain {

	public static void main(String[] args) {
		int arrayToFind[] = {1, 5, 4, 6, 9, 10 };
        int size = arrayToFind.length;
        System.out.println("Original Int Array: " +Arrays.toString(arrayToFind)+"\n");
		AvgGreaterNumber grtNumb= new AvgGreaterNumber();
        grtNumb.printAvgNumb(arrayToFind, size);
	}

}
 class AvgGreaterNumber {
	
	 void printAvgNumb(int arrayToFind[], int size)
    {
        double avg = 0;
        for (int i = 0; i < size; i++)
            avg =avg+ arrayToFind[i];
            avg = avg / size;
     System.out.println("Average number of array is: " +avg+"\n");
     System.out.print("The numbers greater than the average are: ");
        for (int i = 0; i < size; i++)
            if (arrayToFind[i] > avg)
                System.out.print(arrayToFind[i] + " ");
        
    }
}


