/*Write down program to find third maximum of given numbers*/

class FindThirdLargestNumber {
		public static int getThirdLargest(int[] arrayToCheck, int size){  
		int temp;  
		for (int i = 0; i < size; i++)   
		        {  
		            for (int j = i + 1; j < size; j++)   
		            {  
		                if (arrayToCheck[i] > arrayToCheck[j])   
		                {  
		                    temp = arrayToCheck[i];  
		                    arrayToCheck[i] = arrayToCheck[j];  
		                    arrayToCheck[j] = temp;  
		                }  
		            }  
		        }  
		       return arrayToCheck[size-3];  
		}  
		public static void main(String args[]){  
		int a[]={1,2,4,5,3};  
		System.out.println("Third Largest: "+getThirdLargest(arrayToCheck,arrayToCheck.length));  
		}
	}  

