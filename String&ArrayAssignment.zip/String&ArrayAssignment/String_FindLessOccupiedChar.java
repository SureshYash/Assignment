/*Write down program to find out the less occurred character in given sentence*/

public class LessOccupiedCharInSentence {
	public static void main(String[] args) 
	   {  
    String stringToVerfiy="Test Java";
    int[] avg = new int[stringToVerfiy.length()];    
  char minChar = stringToVerfiy.charAt(0);    
  int i, j, min;            
  //char string[] = str.toCharArray(); 
  char string[]= new char[stringToVerfiy.length()];
	for (int z = 0; z < stringToVerfiy.length(); z++) {
		string[z] = stringToVerfiy.charAt(z);
		
  }
  for(i = 0; i < string.length; i++) 
  {    
	  avg[i] = 1;    
      for(j = i+1; j < string.length; j++) 
	  {    
          if(string[i] == string[j] && string[i] != ' ' && string[i] != '0') 
		  {    
        	  avg[i]++;    
              string[j] = '0';    
          }    
      }    
  }    
  min = avg[0];    
  for(i = 0; i <avg.length; i++) 
  {    
      if(min > avg[i] && avg[i] != '0') 
	  {    
          min = avg[i];    
          minChar = string[i];    
      }    
      
  }             
  System.out.println("Minimum occurring character: " + minChar);    
}  

}
