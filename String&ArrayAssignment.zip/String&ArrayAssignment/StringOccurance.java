/*Write down program to find out the occurrence of given string in the sentence. You
need to find out every occurrence of the given string with index and count how many
times string is found.*/

package test;

import java.util.Scanner;

public class CountString {

	// JAVA program to count occurrences
	// of a character

	
		// Method which return count of the given
		// character in the string
		public static int countOccurrences(String sentenceToVerify, String stringToVerify)
		{
			// split the string by spaces in a
		    String sentenceToVerifySplit[] = sentenceToVerify.split(" ");
		 
		    // search for pattern in a
		    int count = 0;
		    for (int i = 0; i < sentenceToVerifySplit.length; i++)
		    {
		    // if match found increase count
		    if (stringToVerify.equals(sentenceToVerifySplit[i]))
		        count++;

		    }

		    System.out.println("index of String:-" +sentenceToVerify.indexOf(sentenceToVerify));

		    return count;
		}
		// Driver method
		public static void main(String args[])
		{
			
			Scanner read = new Scanner(System.in);
            System.out.println("Please enter the String sentence");
			String sentenceToVerify =read.nextLine();
			System.out.println("Given sentence is : -"+sentenceToVerify);
			System.out.println("Please enter the String to check occurence");
			String stringToVerify =read.nextLine();
			System.out.println("Given String is : -"+stringToVerify);

	
			System.out.println("The number of occurence of string is : -"+countOccurrences(sentenceToVerify, stringToVerify));
		}
	}

