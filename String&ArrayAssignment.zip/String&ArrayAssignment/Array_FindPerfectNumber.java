/*Write down program to print all numbers which are perfect numbers from list of
array*/
import java.io.*;
import java.util.*;


public class PrintPerfectNumber
{
	
	 public static void main(String[] args)
	  {
    	    int arrayToFind[] = { 3, 8, 12, 28, 6 };
	 	    int size = arrayToFind.length;
	    countPerfectNumbers(arrayToFind, size);
	  }
		 
	  
	  // Function to count perfect numbers from an array whose sum of digits is also perfect
	  static void countPerfectNumbers(int arr[], int length)
	  {
	    for (int i = 0; i < length; ++i) {
	 
	      if (isPerfect(arr[i])) { //calling isPerfect method to verfiy
	          System.out.print(arr[i] + " ");
			  }
	    }
	  }	 
	  
	// To check if a number is perfect number or not
		  static boolean isPerfect(int numberTocheck)
		  {
		    int sumOfDivisors = 1;
		    for (int i = 2; i <= numberTocheck / 2; ++i) { 
		 
		      if (numberTocheck % i == 0) { //checking is even
		        sumOfDivisors += i;
		      }
		    }
		    if (sumOfDivisors == numberTocheck) {
		      return true;
		    }
		 
		    else
		      return false;
		  }
	}


