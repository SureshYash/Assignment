/*Write down program to create a matrix of following type first row 4 column, second
row 3 column, third row 2 column, fourth row 1 column. User will enter first row
column and accordingly all remaining columns will be created by your logic*/

public class CountMatrix {
	
		public static void countMatrixNumber(int m) {
			for (int i = m; i > 0; i--) {
				int k = 1;
				for (int j = i; j > 0; j--) {
					System.out.print(k++);
				}
				System.out.println();
			}
		}

		public static void main(String[] args) {

			countMatrixNumber(4);
		}
	}
