/*Write down program to match two strings. In this you have to first remove all vowel
from the string and then you have to match the string. You have to print how many
character is not same*/

public class Vowel {
	public static void main(String[] args) {
		String stringToCheck = "Suresh";
		String stringToComp = "Vimal";
		String reslutString = stringToCheck.concat(stringToComp);
		System.out.println(reslutString);
		reslutString = reslutString.replaceAll("[aeiou]", "");
		System.out.println(reslutString);
		for (int i = 0; i < reslutString.length(); i++) {
			int count = 0;
			for (int j = 0; j < reslutString.length(); j++) {
				if (reslutString.charAt(i) == reslutString.charAt(j) && i != j) {
					count++;
					break;

				}
			}
			if (count == 0)
				System.out.println(reslutString.charAt(i));
		}

	}
}
